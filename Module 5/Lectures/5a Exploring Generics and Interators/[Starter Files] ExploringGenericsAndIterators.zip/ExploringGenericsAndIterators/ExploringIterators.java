import java.util.*;

public class ExploringIterators {
   public static void main(String[] args) {
      Random rand = new Random();
      GrabBag<String> things = new GrabBag<>();
      
   }
   
   public static void populate(GrabBag<String> bag, int num, Random r) {
   }
}