public class SyntaxCheckerClient {
	public static void main(String[] args) {
		SyntaxChecker check = new SyntaxChecker("expressions.txt");
		System.out.println(check);
	}
}
