/*
MyStack<E>()   Constructs a new stack with elements of type E 
push(val)      Places val on top of the stack
pop()          Removes top value from the stack and returns it; throws NoSuchElementException if stack is empty
peek()         Returns top value from the stack without removing it; throws NoSuchElementException if stack is empty
isEmpty()      Returns true if the stack has no elements
size()         Returns the number of elements in the stack
*/

import java.util.*;

public class MyStack<E> {

   public MyStack() {}
   
   public void push(E val) {}
   
   public E pop() {}
   
   public E peek() {}
   
   public boolean isEmpty() {}
   
   public int size() {}
   
   public String toString() {}

}